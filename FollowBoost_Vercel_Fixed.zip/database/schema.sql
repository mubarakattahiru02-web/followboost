CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 country TEXT, currency TEXT NOT NULL DEFAULT 'USD', role TEXT NOT NULL DEFAULT 'user',
 status TEXT NOT NULL DEFAULT 'active', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS device_links(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), device_hash TEXT UNIQUE NOT NULL,
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, blocked BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS point_wallets(user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,balance BIGINT NOT NULL DEFAULT 0 CHECK(balance>=0));
CREATE TABLE IF NOT EXISTS point_ledger(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 type TEXT NOT NULL,amount BIGINT NOT NULL,reference TEXT,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS daily_checkins(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 checkin_date DATE NOT NULL,streak INT NOT NULL DEFAULT 1,reward BIGINT NOT NULL,UNIQUE(user_id,checkin_date));
CREATE TABLE IF NOT EXISTS referrals(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),referrer_id UUID NOT NULL REFERENCES users(id),
 referred_id UUID UNIQUE NOT NULL REFERENCES users(id),status TEXT NOT NULL DEFAULT 'pending',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS point_packages(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),name TEXT NOT NULL,points BIGINT NOT NULL,price NUMERIC(12,2) NOT NULL,
 currency TEXT NOT NULL DEFAULT 'USD',active BOOLEAN NOT NULL DEFAULT TRUE);
CREATE TABLE IF NOT EXISTS payments(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),user_id UUID NOT NULL REFERENCES users(id),package_id UUID NOT NULL REFERENCES point_packages(id),
 provider TEXT NOT NULL,provider_reference TEXT,amount NUMERIC(12,2) NOT NULL,currency TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS social_profiles(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 platform TEXT NOT NULL,public_url TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active',UNIQUE(user_id,platform));
CREATE TABLE IF NOT EXISTS reports(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),reporter_id UUID NOT NULL REFERENCES users(id),
 target_user_id UUID NOT NULL REFERENCES users(id),reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS admin_audit_logs(
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),admin_id UUID NOT NULL REFERENCES users(id),
 action TEXT NOT NULL,target_id UUID,metadata JSONB,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());

INSERT INTO point_packages(name,points,price,currency)
SELECT * FROM (VALUES
 ('Starter',500,1.00,'USD'),('Basic',2000,3.00,'USD'),('Popular',5000,6.00,'USD'),
 ('Pro',10000,10.00,'USD'),('Premium',25000,20.00,'USD')) v(name,points,price,currency)
WHERE NOT EXISTS(SELECT 1 FROM point_packages);
